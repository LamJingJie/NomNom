import { StyleSheet, Text, View } from "react-native";
import { Link } from 'expo-router';

export default function FriendsScreen() {
  return (
    <View>
      <Text>friends</Text>
    </View>
  )
}


const styles = StyleSheet.create({

});